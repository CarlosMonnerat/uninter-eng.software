package uninter_java;

public abstract class Moeda { 			// Classe abstrata de todas as moedas do cofrinho

	 protected double valor;
	 
	 public abstract void info();
	 public abstract double converter();
}
