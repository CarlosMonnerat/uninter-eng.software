#!/bin/bash
#/**
# * Script de criação de um HBase no WSL2 (Linux no Windows).
# * Arquivo opcional para estudos no banco de dados NoSQL
# * HBase para a matéria de Bancos de dados NoSQL.
# */
# Uso: instala_hbase_no_wsl.sh fará a verificação se seu WSL já possui o
# HBase instalado.
# - Caso não esteja, ele fará a instalação e inicialização do serviço. 
# - Caso seu HBase já esteja instalado, este script inicializará o servidor HBase.
# - Caso o seu servidor HBase já esteja instalado e em execução, você será informado.


# Configuração de cores para mensagens no terminal
# Cores
FG_COLOR_RED='\033[38;2;255;149;128m'
FG_COLOR_GREEN='\033[38;2;138;255;128m'
FG_COLOR_BLUE='\033[38;2;149;128;255m'
BG_COLOR="\033[48;2;0;57;100m"
FG_COLOR_WHITE="\033[38;2;255;255;255m"
FG_COLOR_YELLOW="\033[38;2;254;167;22m"
BG_RESET="\033[49m"
RESET="\033[0m" # Reseta cores de texto e fundo

# Largura da caixa
BOXWIDTH=80

# Função para adicionar espaços e bordas, considerando códigos de cor
pad_line() {
    # Remove códigos de cor para calcular o comprimento correto
    local plain=$(echo -e "$1" | sed 's/\x1b\[[0-9;]*m//g')
    printf "${BG_COLOR}| %b" "$1"  # %b permite interpretar backslashes para códigos de cor
    local pad=$(($BOXWIDTH - 2 - ${#plain}))
    printf '%*s' $pad '|'
    echo -e " ${BG_RESET}"
}

pad_line_centered() {
    local message="$1"
    # Remove os códigos de cor para cálculo correto do comprimento do texto
    local plain=$(echo -e "$message" | sed 's/\x1b\[[0-9;]*m//g')
    # Calcula o preenchimento necessário para centralizar cada linha
    local message_pad=$(( (BOXWIDTH - 2 - ${#plain}) / 2 - 1 ))   
    pad_line "$(printf '%*s' $message_pad '')$message"
}

# Função para exibir mensagens padrão
display_message() {
    local mensagem="$1"
    echo -e "${BG_COLOR}$(printf '%0.1s' ' '{1..81})${BG_RESET}"
    echo -e "${RESET}${BG_COLOR}+$(printf '%0.1s' '-'{1..78})+ ${BG_RESET}"
    pad_line ""
    pad_line_centered "${RESET}${BG_COLOR}$mensagem"
    pad_line ""
    echo -e "${RESET}${BG_COLOR}+$(printf '%0.1s' '-'{1..78})+ ${RESET}"
    echo -e "${BG_COLOR}$(printf '%0.1s' ' '{1..81})${BG_RESET}"
}

# Função para exibir mensagens de erro
display_error() {
    local message="$1"
    local advice="$2"
    echo -e "${BG_COLOR}$(printf '%0.1s' ' '{1..81})${BG_RESET}"
    echo -e "${FG_COLOR_RED}${BG_COLOR}+$(printf '%0.1s' '-'{1..78})+ ${BG_RESET}"
    pad_line ""
    pad_line_centered "${FG_COLOR_RED}${BG_COLOR}$message${FG_COLOR_RED}${BG_COLOR}"
    pad_line_centered "${RESET}${BG_COLOR}$advice${FG_COLOR_RED}${BG_COLOR}"
    pad_line ""
    echo -e "${FG_COLOR_RED}${BG_COLOR}+$(printf '%0.1s' '-'{1..78})+ ${BG_RESET}"
    echo -e "${BG_COLOR}$(printf '%0.1s' ' '{1..81})${RESET}"
}

display_start_message() {
    echo -e "${BG_COLOR}$(printf '%0.1s' ' '{1..81})${BG_RESET}"
    echo -e "${RESET}${BG_COLOR}+$(printf '%0.1s' '-'{1..78})+ ${BG_RESET}"
    pad_line ""
    pad_line "$(printf '%0.1s' ' '{1..12})${FG_COLOR_YELLOW}INSTALADOR DO HBASE PARA ESTUDOS DA MATÉRIA DE NoSQL${RESET}${BG_COLOR}"
    pad_line ""
    pad_line "$(printf '%0.1s' ' '{1..34})${FG_COLOR_YELLOW}UNINTER${RESET}${BG_COLOR}"
    pad_line ""
    pad_line "Este script instalará os seguintes componentes em seu linux:"
    pad_line "- nano"
    pad_line "- wget"
    pad_line "- openjdk-8-jdk"
    pad_line "- gedit"
    pad_line "- HBase 2.5.8"
    pad_line ""
    pad_line "${FG_COLOR_GREEN}${BG_COLOR}Após a instalação, o servidor HBase será iniciado.${RESET}${BG_COLOR}"
    pad_line ""
    echo -e "${RESET}${BG_COLOR}+$(printf '%0.1s' '-'{1..78})+ ${BG_RESET}"
    echo -e "${BG_COLOR}$(printf '%0.1s' ' '{1..81})${RESET}"
}

display_logo() {
    # Imprime logo N-CPU UNINTER.
    echo -e "${FG_COLOR_YELLOW}${BG_COLOR}$(printf '%0.1s' ' '{1..81})${RESET}\n${FG_COLOR_YELLOW}${BG_COLOR}$(printf '%0.1s' ' '{1..81})${RESET}\n${FG_COLOR_YELLOW}${BG_COLOR}$(printf '%0.1s' ' '{1..81})${RESET}\n${FG_COLOR_YELLOW}${BG_COLOR}                        #        #$(printf '%0.1s' ' '{1..47})${RESET}\n${FG_COLOR_YELLOW}${BG_COLOR}                 #     ##        ##     #$(printf '%0.1s' ' '{1..40})${RESET}\n${FG_COLOR_YELLOW}${BG_COLOR}                #########        #########$(printf '%0.1s' ' '{1..39})${RESET}\n${FG_COLOR_YELLOW}${BG_COLOR}             ####     ##          ##     ####$(printf '%0.1s' ' '{1..36})${RESET}\n${FG_COLOR_YELLOW}${BG_COLOR}               ##     ##          ##     ##$(printf '%0.1s' ' '{1..38})${RESET}\n${FG_COLOR_YELLOW}${BG_COLOR}           #############          #############$(printf '%0.1s' ' '{1..34})${RESET}\n${FG_COLOR_YELLOW}${BG_COLOR}          ##############          ##############$(printf '%0.1s' ' '{1..33})${RESET}\n${FG_COLOR_YELLOW}${BG_COLOR}              ##      ##          ##      ##$(printf '%0.1s' ' '{1..37})${RESET}\n${FG_COLOR_YELLOW}${BG_COLOR}              ##      ##          ##      ##    ${FG_COLOR_WHITE}${BG_COLOR}&&&$(printf '%0.1s' ' '{1..30})${RESET}\n${FG_COLOR_YELLOW}${BG_COLOR}              ##      ##          ##      ##      ${FG_COLOR_WHITE}${BG_COLOR}&&&$(printf '%0.1s' ' '{1..28})${RESET}\n${FG_COLOR_YELLOW}${BG_COLOR}          ######################################   ${FG_COLOR_WHITE}${BG_COLOR}&&$(printf '%0.1s' ' '{1..28})${RESET}\n${FG_COLOR_YELLOW}${BG_COLOR}           ####################################   ${FG_COLOR_WHITE}${BG_COLOR}&&&$(printf '%0.1s' ' '{1..28})${RESET}\n${FG_COLOR_YELLOW}${BG_COLOR}               ##     ##          ##     ##      ${FG_COLOR_WHITE}${BG_COLOR}&&$(printf '%0.1s' ' '{1..30})${RESET}\n${FG_COLOR_YELLOW}${BG_COLOR}             ####     ##          ##     ####  ${FG_COLOR_WHITE}${BG_COLOR}&&&$(printf '%0.1s' ' '{1..31})${RESET}\n${FG_COLOR_WHITE}${BG_COLOR}          &&${FG_COLOR_YELLOW}${BG_COLOR}    ##########################   ${FG_COLOR_WHITE}${BG_COLOR}&&$(printf '%0.1s' ' '{1..34})${RESET}\n${FG_COLOR_WHITE}${BG_COLOR}         &${FG_COLOR_YELLOW}${BG_COLOR}       #     ##        ##     # ${FG_COLOR_WHITE}${BG_COLOR}&&&$(printf '%0.1s' ' '{1..36})${RESET}\n${FG_COLOR_WHITE}${BG_COLOR}        &&${FG_COLOR_YELLOW}${BG_COLOR}              #        #   ${FG_COLOR_WHITE}${BG_COLOR}&&&&&$(printf '%0.1s' ' '{1..39})${RESET}\n${FG_COLOR_WHITE}${BG_COLOR}        &&&&&&             @@@@   &&&&$(printf '%0.1s' ' '{1..43})${RESET}\n${FG_COLOR_WHITE}${BG_COLOR}          &&&&&&&&&&&&&&&=@@@@@@=&&$(printf '%0.1s' ' '{1..46})${RESET}\n${FG_COLOR_WHITE}${BG_COLOR}                &&&&&      @@@@$(printf '%0.1s' ' '{1..50})${RESET}\n${FG_COLOR_WHITE}${BG_COLOR}$(printf '%0.1s' ' '{1..81})${RESET}\n${FG_COLOR_WHITE}${BG_COLOR} &&&&    &&&& &&&&    &&&& &&&& &&&&    &&&& &&&&&&&&&&& &&&&&&&&&& &&&&&&&&&&&$(printf '%0.1s' ' '{1..2})${RESET}\n${FG_COLOR_WHITE}${BG_COLOR} &&&&    &&&& &&&&&   &&&& &&&& &&&&&   &&&& &&&&&&&&&&& &&&&&&&&&& &&&&&&&&&&&&$(printf '%0.1s' ' '{1..1})${RESET}\n${FG_COLOR_WHITE}${BG_COLOR} &&&&    &&&& &&&&&&  &&&& &&&& &&&&&&  &&&&    &&&&     &&&&       &&&&    &&&&$(printf '%0.1s' ' '{1..1})${RESET}\n${FG_COLOR_WHITE}${BG_COLOR} &&&&    &&&& &&&&&&& &&&& &&&& &&&&&&& &&&&    &&&&     &&&&       &&&&    &&&&$(printf '%0.1s' ' '{1..1})${RESET}\n${FG_COLOR_WHITE}${BG_COLOR} &&&&    &&&& &&&&&&&&&&&& &&&& &&& &&&&&&&&    &&&&     &&&&&&&&&& &&&&&&&&&&&$(printf '%0.1s' ' '{1..2})${RESET}\n${FG_COLOR_WHITE}${BG_COLOR} &&&&    &&&& &&&& &&&&&&& &&&& &&&  &&&&&&&    &&&&     &&&&       &&&&&&&&&&$(printf '%0.1s' ' '{1..3})${RESET}\n${FG_COLOR_WHITE}${BG_COLOR} &&&&    &&&& &&&&  &&&&&& &&&& &&&   &&&&&&    &&&&     &&&&       &&&&  &&&&$(printf '%0.1s' ' '{1..3})${RESET}\n${FG_COLOR_WHITE}${BG_COLOR}  &&&&&&&&&&  &&&&   &&&&& &&&& &&&    &&&&&    &&&&     &&&&&&&&&& &&&&   &&&&$(printf '%0.1s' ' '{1..2})${RESET}\n${FG_COLOR_WHITE}${BG_COLOR}   &&&&&&&&   &&&&    &&&& &&&& &&&     &&&&    &&&&     &&&&&&&&&& &&&&    &&&&$(printf '%0.1s' ' '{1..1})${RESET}\n${FG_COLOR_WHITE}${BG_COLOR}$(printf '%0.1s' ' '{1..81})${RESET}\n${FG_COLOR_WHITE}${BG_COLOR}$(printf '%0.1s' ' '{1..81})${RESET}\n${FG_COLOR_WHITE}${BG_COLOR}$(printf '%0.1s' ' '{1..81})${RESET}\n${FG_COLOR_WHITE}${BG_COLOR}$(printf '%0.1s' ' '{1..81})${RESET}\n${FG_COLOR_WHITE}${BG_COLOR}                     &&    &&         &&&&&&   &&&&&   &&    &&$(printf '%0.1s' ' '{1..18})${RESET}\n${FG_COLOR_WHITE}${BG_COLOR}                     &&&   &&        &&    && &&    && &&    &&$(printf '%0.1s' ' '{1..18})${RESET}\n${FG_COLOR_WHITE}${BG_COLOR}                     && &  &&        &&       &&    && &&    &&$(printf '%0.1s' ' '{1..18})${RESET}\n${FG_COLOR_WHITE}${BG_COLOR}                     &&  & &&  &&&&& &&       &&&&&&   &&    &&$(printf '%0.1s' ' '{1..18})${RESET}\n${FG_COLOR_WHITE}${BG_COLOR}                     &&   &&&        &&    && &&       &&    &&$(printf '%0.1s' ' '{1..18})${RESET}\n${FG_COLOR_WHITE}${BG_COLOR}                     &&    &&         &&&&&&  &&       &&&&&&&&$(printf '%0.1s' ' '{1..18})${RESET}\n${FG_COLOR_WHITE}${BG_COLOR}$(printf '%0.1s' ' '{1..81})${RESET}\n${FG_COLOR_WHITE}${BG_COLOR}$(printf '%0.1s' ' '{1..81})${RESET}"
}

display_final_message() {
    # Mensagem final para o usuário:
    echo -e "${BG_COLOR}$(printf '%0.1s' ' '{1..81})${BG_RESET}"
    echo -e "${FG_COLOR_GREEN}${BG_COLOR}+$(printf '%0.1s' '-'{1..78})+ ${BG_RESET}"
    pad_line ""
    pad_line_centered "Servidor HBase iniciado com sucesso"
    pad_line ""
    pad_line_centered "Acesse o HBase pelo seguinte endereço em seu navegador:"
    pad_line_centered "${RESET}${BG_COLOR}(CTRL + click para abrir se estiver usando o Windows Terminal)${FG_COLOR_GREEN}${BG_COLOR}"
    pad_line ""
    pad_line_centered "${FG_COLOR_BLUE}${BG_COLOR}http://localhost:16010${FG_COLOR_GREEN}${BG_COLOR}"
    pad_line ""
    pad_line ""
    pad_line "${RESET}${BG_COLOR}- Caso o link acima não funcione, inicie o servidor do HBase manualmente:${FG_COLOR_GREEN}${BG_COLOR}"
    pad_line ""
    pad_line_centered "${FG_COLOR_GREEN} sudo $HOME/hbase/bin/start-hbase.sh ${FG_COLOR_GREEN}${BG_COLOR}"
    pad_line ""
    pad_line "${RESET}${BG_COLOR}- Para parar o servidor do HBase, execute:${FG_COLOR_GREEN}${BG_COLOR}"
    pad_line ""
    pad_line_centered "${FG_COLOR_RED} sudo $HOME/hbase/bin/stop-hbase.sh ${FG_COLOR_GREEN}${BG_COLOR}"
    pad_line ""
    echo -e "${FG_COLOR_GREEN}${BG_COLOR}+$(printf '%0.1s' '-'{1..78})+ ${BG_RESET}"
    echo -e "${BG_COLOR}$(printf '%0.1s' ' '{1..81})${RESET}"
}

show_usage() {
    # Mensagem de ajuda para o usuário:
    echo -e "${BG_COLOR}$(printf '%0.1s' ' '{1..81})${BG_RESET}"
    echo -e "${RESET}${BG_COLOR}+$(printf '%0.1s' '-'{1..78})+ ${BG_RESET}"
    pad_line ""
    pad_line_centered "${FG_COLOR_YELLOW}${BG_COLOR}AJUDA${RESET}${BG_COLOR}"
    pad_line ""
    pad_line "Uso: sudo ./instala_hbase_no_wsl.sh [OPÇÃO]"
    pad_line
    pad_line "Este script instala, desinstala ou verifica o estado do HBase no WSL."
    pad_line
    pad_line "Opções:"
    pad_line "  -h, --help          Mostra esta ajuda e sai."
    pad_line "  -d, --desinstala    Desinstala o HBase do sistema. Requer que o script"
    pad_line "                      seja executado com privilégios de superusuário."
    pad_line "                      Esta opção irá parar o serviço do HBase se estiver"
    pad_line "                      em execução e removerá a pasta de instalação."
    pad_line
    pad_line "Sem argumentos:"
    pad_line "  Executar o script sem argumentos iniciará a instalação do HBase ou, caso"
    pad_line "  o HBase já esteja instalado, inicializará o servidor."
    pad_line
    pad_line "Importante:"
    pad_line "  Para a instalação ou desinstalação, é necessário que o script seja"
    pad_line "  executado com privilégios de superusuário (sudo)."
    pad_line
    pad_line "Exemplos:"
    pad_line "  sudo ./instala_hbase_no_wsl.sh               # Instala ou inicia o HBase"
    pad_line "  sudo ./instala_hbase_no_wsl.sh --desinstala  # Para e desinstala o HBase"
    pad_line "  sudo ./instala_hbase_no_wsl.sh --help        # Mostra a ajuda"
    pad_line ""
    pad_line "Mais informações:"
    pad_line "O script instalará e ativará o HBase em seu WSL."
    pad_line ""
    pad_line "- Caso o HBase já esteja instalado, o servidor será iniciado."
    pad_line "- Caso o seu servidor já esteja em execução, você será informado."
    pad_line "- Caso o HBase não esteja instalado, a instalação e inicialização"
    pad_line "  do serviço será realizada."
    pad_line ""
    echo -e "${RESET}${BG_COLOR}+$(printf '%0.1s' '-'{1..78})+ ${BG_RESET}"
    echo -e "${BG_COLOR}$(printf '%0.1s' ' '{1..81})${RESET}"
}

# Verifica se o HBase está em execução usando ps e grep
check_hbase_running() {
    if ps -ef | grep '[H]Master' > /dev/null; then
        return 0 # HBase está rodando
    else
        return 1 # HBase não está rodando
    fi
}

################################################################################

# Mostra mensagem de ajuda.
if [ "--help" = "$1" ] || [ "-h" = "$1" ]; then
    show_usage
    exit 0
fi

# Verificação inicial de privilégios de superusuário.
if [ "$(id -u)" != "0" ]; then
    display_error "Este script precisa ser executado como superusuário." "Use ${FG_COLOR_GREEN}${BG_COLOR}sudo ./instala_hbase_no_wsl.sh"
    exit 1
fi

# Opção de desinstalação do HBase:
if [ "--desinstala" = "$1" ] || [ "-d" = "$1" ]; then
    if [ -x "$HOME/hbase/bin" ]; then
        if check_hbase_running; then
            # HBase já está em execução
            display_message "O HBase está em execução. Parando servidor."
            sudo "$HOME/hbase/bin/stop-hbase.sh"
            # Espera o HBase parar completamente
            while check_hbase_running; do
                sleep 1  # espera 1 segundo antes de checar novamente
            done
            display_message "Servidor HBase parado com sucesso."
        fi
        display_message "Deletando a pasta HBase."
        sudo rm -Rf $HOME/hbase
        display_message "HBase desinstalado com sucesso."
        exit 0
    else
        display_message "HBase não instalado."
        exit 0
    fi
fi

# Verificação de instalação já realizada:
if [ -x "$HOME/hbase/bin/start-hbase.sh" ]; then
    if check_hbase_running; then
        # HBase já está em execução
        display_logo
        display_message "O HBase já esteja em execução."
        display_final_message
        exit 0
    else
        # Tenta executar o script start-hbase.sh
        if sudo "$HOME/hbase/bin/start-hbase.sh"; then
            display_logo
            display_final_message
            exit 0
        else
            display_error "Falha ao iniciar o HBase." "Entre em contato com a Tutoria."
            exit 1
        fi
    fi
fi

display_start_message

display_message "Atualizando os pacotes do sistema..."


if ! sudo apt-get update && sudo apt-get upgrade -y; then
    display_error "Falha ao atualizar pacotes." "Verifique sua conexão com a internet ou repositórios."
    exit 1
fi

# Instalações de dependências:
# - nano para editar textos no terminal.
# - wget para fazer downloads de links.
# - openjdk-8-jdk para usar o java jdk 8.
# - gedit para usar o editor de texto visual.
display_message "Instalando dependências: nano, wget e openjdk-8-jdk..."

if ! sudo apt-get install -y nano wget openjdk-8-jdk; then
    display_error "Falha na instalação das dependências." "Verifique sua conexão com a internet ou repositórios apt."
    exit 1
fi

display_message "Instalando o editor gedit via snap..."

# Tenta instalar o gedit via snap
if ! sudo snap install gedit; then
    # Se falhar, instala o snapd e o systemd-genie
    if sudo apt install -y snapd systemd-genie; then
    # Inicia o ambiente systemd com genie
    genie -s
    # Tenta iniciar o snapd e instalar o gedit novamente
    if sudo systemctl start snapd && sudo snap install gedit; then
        display_message "Gedit instalado com sucesso via Snap."
    else
        # Se ainda falhar, tenta instalar o gedit via apt-get
        if sudo apt-get install -y gedit; then
            display_message "Gedit instalado com sucesso via apt-get."
        else
            display_error "Falha ao instalar o gedit (instalação não obrigatória)." "Verifique se você está usando o WSL 2 e seus repositórios snap."
        fi
    fi
    else
    # Se não conseguir instalar snapd e genie
        display_error "Falha ao preparar o ambiente para Snap." "Etapa não brigatória. Você pode entrar em contato com a Tutoria se desejar."
    fi
else
    display_message "Gedit instalado com sucesso via Snap."
fi

# Configuração da variável de ambiente JAVA_HOME.
display_message "Configurando JAVA_HOME..."
echo "export JAVA_HOME=/usr/lib/jvm/java-8-openjdk-amd64" >> $HOME/.profile
source $HOME/.profile

# Download do HBase 2.5.8 (arquivos binários apenas)
# Local e nome dos arquivos
FILE="$HOME/hbase-2.5.8-bin.tar.gz"
URL="https://dlcdn.apache.org/hbase/2.5.8/hbase-2.5.8-bin.tar.gz"

display_message "Baixando o HBase 2.5.8..."
if ! wget -O "$FILE" "$URL"; then
    display_error "Falha no download do HBase." "Verifique sua conexão com a internet."
    exit 1
fi

# Download do arquivo SHA512
if ! wget -O "$FILE.sha512" "$URL.sha512"; then
    display_error "Falha no download do checksum." "Verifique sua conexão com a internet."
    exit 1
fi

# Verificação do SHA-512
display_message "Verificando a integridade do arquivo baixado..."

downloaded_checksum=$(cat "$FILE.sha512" | tr -d '[:space:]' | cut -d ':' -f2)
generated_checksum=$(gpg --print-md SHA512 "$FILE" | tr -d '[:space:]' | cut -d ':' -f2)

if [ "$generated_checksum" == "$downloaded_checksum" ]; then
    display_message "A verificação de checksum foi bem-sucedida. O arquivo está íntegro."
    rm -f "$FILE.sha512"  # Remover arquivo de checksum
else
    display_error "A verificação de checksum falhou." "O arquivo pode estar corrompido. Tente novamente ou avise a tutoria."
    rm -f "$FILE"  # Remover arquivo corrompido
    rm -f "$FILE.sha512"  # Remover arquivo de checksum
    exit 1
fi

#  Criação da pasta hbase na home do usuário, se não existir
display_message "Preparando diretório para o HBase..."
mkdir -p $HOME/hbase

# Descompacta o arquivo tar.gz baixado para a pasta hbase e deleta arquivo baixado
display_message "Descompactando o HBase..."
if ! tar -xf $HOME/hbase-2.5.8-bin.tar.gz -C $HOME/hbase --strip-components=1; then
    display_error "Falha ao descompactar o HBase." "Entre em contato com a tutoria."
    rm -f $HOME/hbase-2.5.8-bin.tar.gz
    exit 1
else
    rm -f $HOME/hbase-2.5.8-bin.tar.gz  
fi

# Usa o sed para alterar a linha export JAVA_HOME no arquivo hbase-env.sh da pasta hbase/conf
display_message "Configurando arquivo de ambiente do HBase..."
if ! sed -i 's/^#\? *export JAVA_HOME=.*/export JAVA_HOME=\/usr\/lib\/jvm\/java-8-openjdk-amd64/' $HOME/hbase/conf/hbase-env.sh; then
    display_error "Falha ao configurar JAVA_HOME no HBase." "Entre em contato com a tutoria."
    exit 1
fi

# Define o caminho para a propriedade hbase.rootdir
HBASE_ROOTDIR_VALUE="file:$HOME/hbase"

# Usa o awk para inserir a nova propriedade antes da tag </configuration> no arquivo hbase/conf/hbase-site.xml
# Salva como arquivo temporário hbase-site.tmp
display_message "Configurando propriedade hbase.rootdir..."
if ! awk -v path="$HBASE_ROOTDIR_VALUE" '
    /<\/configuration>/ {
        print "  <property>"
        print "    <name>hbase.rootdir</name>"
        print "    <value>" path "</value>"
        print "  </property>"
    }
    {print}
' $HOME/hbase/conf/hbase-site.xml > $HOME/hbase/conf/hbase-site.tmp || ! mv $HOME/hbase/conf/hbase-site.tmp $HOME/hbase/conf/hbase-site.xml; then
    display_error "Falha ao configurar hbase.rootdir." "Entre em contato com a tutoria."
    exit 1
fi

# Inicia o servidor HBase em localhost:16010
display_message "Iniciando o servidor HBase..."

if check_hbase_running; then
        # HBase já está em execução
        display_logo
        display_message "O HBase já esteja em execução."
        display_final_message
        exit 0
else
    # Tenta executar o script start-hbase.sh
    if sudo "$HOME/hbase/bin/start-hbase.sh"; then
        display_logo
        display_final_message
        exit 0
    else
        display_error "Falha ao iniciar o HBase." "Entre em contato com a Tutoria."
        exit 1
    fi
fi